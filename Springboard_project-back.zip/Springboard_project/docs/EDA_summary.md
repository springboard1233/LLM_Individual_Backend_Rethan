
# EDA Summary for fraud_detection.csv

## Transaction Amount Distribution  
![Amount](amount_distribution.png)

## Transactions by Channel  
![Channel](channel_count.png)

## Transactions by Hour  
![Hour](hour_count.png)

## Transactions by Weekday  
![Weekday](weekday_count.png)

## Correlation Heatmap  
![Corr](correlation_heatmap.png)

Generated: 2025-09-11 12:31:40.973108
